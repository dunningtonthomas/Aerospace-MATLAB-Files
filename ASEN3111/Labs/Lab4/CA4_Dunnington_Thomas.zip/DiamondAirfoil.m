function [c_l,c_dw] = DiamondAirfoil(M, alpha, epsilon1, epsilon2)
%AUTHOR: Thomas Dunnington
%COLLABORATORS: Nolan Stevenson, Owen Craig, Carson Kohlbrenner, Chase Rupprecht
%DATE: 4/26/2023
%DIAMONDAIRFOIL 
%SUMMARY: This function uses shock expansion theory to calculate the
%coefficient of lift and wave drag for a diamond airfoil with given angles
%INPUTS:
%   M = freestream mach number
%   alpha = angle of attack
%   epsilon1 = leading edge angle of diamond airfoil
%   epsilon2 = trailing edge angle of diamond airfoil
%OUTPUTS:
%   c_l = coefficient of lift
%   c_dw = coefficient of drag (wave drag)
%REGION NOMENCLATURE:
%     (A)/\(C)
%       /  \
%       \  / 
%     (B)\/(D)


%Test if the airfoil creates a bow shock
maxAngle = abs(alpha) + epsilon1; %Maximum angle to produce a shock
[Betad] = ObliqueShockBeta(M,maxAngle,1.4,'Weak');

if(imag(Betad) ~= 0 || Betad < 0) %Condition for bow shock
    c_l = 0xDEADBEEF; %Return error code
    c_dw = 0xDEADBEEF;
    return;
end


%Conditions for fan on the top surface and shock on bottom
if(alpha - epsilon1 > 0)
    %%%%REGION A
    %Compute fan on top surface Region A
    [~,nu1,~] = flowprandtlmeyer(1.4,M); 
    nuA = nu1 + (alpha - epsilon1);

    %Get mach number after the fan
    [MA,~,~] = flowprandtlmeyer(1.4,nuA,'nu');

    %Use isentropic relations to get the pressure in region A
    [~,~,pA,~,~] = flowisentropic(1.4,MA, 'mach');

    %%%%REGION B
    %Find the shock in region B
    Thetad = alpha + epsilon1;
    [Betad] = ObliqueShockBeta(M,Thetad,1.4,'Weak');

    %Normal component
    Mn = M * sind(Betad);

    %Call the normal shock equation
    [~,~,pB,~,MBn,~,~] = flownormalshock(1.4,Mn,'mach');

    %Find MB
    MB = MBn / sind(Betad - Thetad);

    %%%%REGION C
    %Expansion fan turned by epsilon1 + epsilon2
    [~,nuA,~] = flowprandtlmeyer(1.4,MA); 
    nuC = nuA + (epsilon1 + epsilon2);

    %Get mach number after the fan
    [MC,~,~] = flowprandtlmeyer(1.4,nuC,'nu');

    %Use isentropic relations to get the pressure in region C
    [~,~,pC,~,~] = flowisentropic(1.4,MC, 'mach');

    %%%%REGION D
    %Expansion fan turned by epsilon1 + epsilon2
    [~,nuB,~] = flowprandtlmeyer(1.4,MB); 
    nuD = nuB + (epsilon1 + epsilon2);

    %Get mach number after the fan
    [MD,~,~] = flowprandtlmeyer(1.4,nuD,'nu');

    %Use isentropic relations to get the pressure in region D
    [~,~,pD,~,~] = flowisentropic(1.4,MD, 'mach');

elseif(-alpha - epsilon1 > 0) %Condition for fan on bottom and shock on top

    %%%%REGION A
    %Compute shock on top surface Region A
    Thetad = -alpha + epsilon1;
    [Betad] = ObliqueShockBeta(M,Thetad,1.4,'Weak');

    %Normal component
    Mn = M * sind(Betad);

    %Call the normal shock equation
    [~,~,pA,~,MAn,~,~] = flownormalshock(1.4,Mn,'mach');

    %Find MB
    MA = MAn / sind(Betad - Thetad);

    %%%%REGION B
    [~,nu1,~] = flowprandtlmeyer(1.4,M); 
    nuB = nu1 + (-alpha - epsilon1);

    %Get mach number after the fan
    [MB,~,~] = flowprandtlmeyer(1.4,nuB,'nu');

    %Use isentropic relations to get the pressure in region B
    [~,~,pB,~,~] = flowisentropic(1.4,MB, 'mach');

    %%%%REGION C
    %Expansion fan turned by epsilon1 + epsilon2
    [~,nuA,~] = flowprandtlmeyer(1.4,MA); 
    nuC = nuA + (epsilon1 + epsilon2);

    %Get mach number after the fan
    [MC,~,~] = flowprandtlmeyer(1.4,nuC,'nu');

    %Use isentropic relations to get the pressure in region C
    [~,~,pC,~,~] = flowisentropic(1.4,MC, 'mach');

    %%%%REGION D
    %Expansion fan turned by epsilon1 + epsilon2
    [~,nuB,~] = flowprandtlmeyer(1.4,MB); 
    nuD = nuB + (epsilon1 + epsilon2);

    %Get mach number after the fan
    [MD,~,~] = flowprandtlmeyer(1.4,nuD,'nu');

    %Use isentropic relations to get the pressure in region D
    [~,~,pD,~,~] = flowisentropic(1.4,MD, 'mach');

else %Shock on top and bottom could be bow shock
    %Conditions for no fan or shock when alpha == epsilon
    if(alpha == epsilon1)
        %%%%REGION A
        pA = 1;
        MA = M;

        %%%%REGION B
        %Find the shock in region B
        Thetad = alpha + epsilon1;
        [Betad] = ObliqueShockBeta(M,Thetad,1.4,'Weak');
    
        %Normal component
        Mn = M * sind(Betad);
    
        %Call the normal shock equation
        [~,~,pB,~,MBn,~,~] = flownormalshock(1.4,Mn,'mach');
    
        %Find MB
        MB = MBn / sind(Betad - Thetad);

    elseif(-alpha == epsilon1)
        %%%%REGION A
        %Compute shock on top surface Region A
        Thetad = epsilon1 - alpha;
        [Betad] = ObliqueShockBeta(M,Thetad,1.4,'Weak');
    
        %Normal component
        Mn = M * sind(Betad);
    
        %Call the normal shock equation
        [~,~,pA,~,MAn,~,~] = flownormalshock(1.4,Mn,'mach');
    
        %Find MA
        MA = MAn / sind(Betad - Thetad);

        %%%%REGION B
        pB = 1;
        MB = M;
    else %Case where there is a shock in region A and B
        %%%%REGION A
        %Compute shock on top surface Region A
        Thetad = epsilon1 - alpha;
        [Betad] = ObliqueShockBeta(M,Thetad,1.4,'Weak');
    
        %Normal component
        Mn = M * sind(Betad);
    
        %Call the normal shock equation
        [~,~,pA,~,MAn,~,~] = flownormalshock(1.4,Mn,'mach');
    
        %Find MA
        MA = MAn / sind(Betad - Thetad);

        %%%%REGION B
        %Find the shock in region B
        Thetad = alpha + epsilon1;
        [Betad] = ObliqueShockBeta(M,Thetad,1.4,'Weak');
    
        %Normal component
        Mn = M * sind(Betad);
    
        %Call the normal shock equation
        [~,~,pB,~,MBn,~,~] = flownormalshock(1.4,Mn,'mach');
    
        %Find MB
        MB = MBn / sind(Betad - Thetad);
    end

    %%%%REGION C
    %Expansion fan turned by epsilon1 + epsilon2
    [~,nuA,~] = flowprandtlmeyer(1.4,MA); 
    nuC = nuA + (epsilon1 + epsilon2);

    %Get mach number after the fan
    [MC,~,~] = flowprandtlmeyer(1.4,nuC,'nu');

    %Use isentropic relations to get the pressure in region C
    [~,~,pC,~,~] = flowisentropic(1.4,MC, 'mach');

    %%%%REGION D
    %Expansion fan turned by epsilon1 + epsilon2
    [~,nuB,~] = flowprandtlmeyer(1.4,MB); 
    nuD = nuB + (epsilon1 + epsilon2);

    %Get mach number after the fan
    [MD,~,~] = flowprandtlmeyer(1.4,nuD,'nu');

    %Use isentropic relations to get the pressure in region D
    [~,~,pD,~,~] = flowisentropic(1.4,MD, 'mach');
end


%Calculate the coefficient of lift and drag using the pressures
%Define length 1 over c and length 2 over c using law of sines
L1oC = sind(epsilon2) / sind(180 - epsilon1 - epsilon1);
L2oC = sind(epsilon1) / sind(180 - epsilon1 - epsilon1);


%Coefficent calculations
c_l = 1 / (1.4 / 2 * M^2) * (pB*L1oC*cosd(epsilon1 + alpha) + pD*L2oC*cosd(alpha - epsilon2) - pA*L1oC*cosd(alpha - epsilon1) - pC*L2oC*cosd(alpha + epsilon2));
c_dw = 1 / (1.4 / 2 * M^2) * (pB*L1oC*sind(epsilon1 + alpha) + pD*L2oC*sind(alpha - epsilon2) - pA*L1oC*sind(alpha - epsilon1) - pC*L2oC*sind(alpha + epsilon2));

end

