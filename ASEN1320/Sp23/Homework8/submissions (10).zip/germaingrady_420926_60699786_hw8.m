% Load in data.mat file with given information
load data.mat

% Assign values to AltitudeVector and SoundSpeedVector from data.mat
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

% Prompt user to input values for Speed and Altitude
Speed = input("Speed: ");
Altitude = input("Altitude: ");

% Find and index nearest altitude in AltitudeVector from given input
[val,isAltitude] = min(abs(AltitudeVector - Altitude));

% Assign a value for SoundSpeed given the vector index
SoundSpeed = SoundSpeedVector(isAltitude);

% Calculate MachNumber
MachNumber = Speed / SoundSpeed;

% If statement to output the desired response
if (MachNumber < 1)
     % Print regime, and MachNumber to 2 decimal places
     fprintf('Subsonic MachNumber: %.2f \n' , MachNumber) 
elseif (MachNumber == 1)
     fprintf('Sonic MachNumber: %.2f \n' , MachNumber) 
elseif (MachNumber > 1 && MachNumber <= 5)
     %Calculate MachAngle in degrees and turn to an integer
     MachAngle = int32(asind(1/MachNumber));
     fprintf('Supersonic MachNumber: %.2f MachAngle: %i \n' , MachNumber, MachAngle) 
else
     fprintf('Hypersonic MachNumber: %.2f \n' , MachNumber)
end