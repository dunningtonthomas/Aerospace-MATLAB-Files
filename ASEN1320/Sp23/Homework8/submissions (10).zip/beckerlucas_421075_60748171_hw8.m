%Program to calculate MachNumber at a given speed and altitude
%Lucas Becker HW8 3/17/23

load data.mat;
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);
Speed = input("Speed: ");
Altitude = input("Altitude: ");

%finds closest value in AltitudeVector array to inputted altitude
Alt = interp1(AltitudeVector, AltitudeVector, Altitude,'nearest','extrap');
isAltitude = find(AltitudeVector == Alt);   %finds index for closest altitude

MachNumber = Speed / (SoundSpeedVector(isAltitude));    %calculates machnumber
A = asin(1/MachNumber); %calculates mach angle
Adegrees = 180 * A / pi;    %converts angle from radians to degrees
Aoutput = round(Adegrees);  %rounds angle

if (MachNumber < 1) %checks if machnumber is subsonic
    fprintf("Subsonic MachNumber: %.2f",MachNumber)
elseif(MachNumber == 1) %checks if machnumber is equal to 1
    fprintf("Sonic MachNumber: %.2f",MachNumber)
elseif(MachNumber > 1 && MachNumber <=5)    %checks if machnumber is supersonic
    fprintf("Supersonic MachNumber: %.2f MachAngle: %i",MachNumber,Aoutput)
else fprintf("Hypersonic MachNumber: %.2f",MachNumber)  %decides machnumber is hypersonic otherwise
end
