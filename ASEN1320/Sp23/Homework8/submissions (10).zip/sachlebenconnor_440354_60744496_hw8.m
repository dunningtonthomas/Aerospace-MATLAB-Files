load data.mat;

%putting the altitude and speed columns from the data matrix into separte
%vectors
AltitudeVector = data(:, 1);
SoundSpeedVector = data(:, 3);

%user inputs
Speed = input("Speed: ");
Altitude = input("Altitude: ");

%Creating a vector of the difference between given altitude and all the
%reference altitudes
diffAlt = (1:38);

for count = 1:38
   diffAlt(count) = abs(Altitude - AltitudeVector(count));
end

%finding the smallest element of the diffAlt vector
[M, isAltitude] = min(diffAlt);

%calculating mach number from the speed and speed of sound at the given alt
machNumber = Speed / SoundSpeedVector(isAltitude);

%getting the output and mach angle depending on the regime
if(machNumber < 1)
    fprintf("Subsonic MachNumber: %.2f\n", machNumber)
end

if(machNumber == 1)
    fprintf("Sonic MachNumber: %.2f\n", machNumber)
end

if(machNumber > 1 && machNumber <= 5)
    A = asind(1/machNumber);
    
    fprintf("Supersoinc MachNumber: %.2f MachAngle: %.0f\n", machNumber, A)
end

if(machNumber > 5)
    fprintf("Hypersonic MachNumber: %.2f\n", machNumber)
end
    