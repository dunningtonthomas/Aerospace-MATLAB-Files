%% Clean up
clear; close all; clc;

%% Loading data
load data.mat;

%% Vectors and inputs
AltitudeVector = data(1:38,1); % assigning alt vec
SoundSpeedVector = data(1:38,3); % assigning speed vec

%Speed = input("Speed: "); % taking inputs
%Altitude = input("Altitude: ");

[X, isAltitude] = min(abs(AltitudeVector - Altitude)); % finding nearest altitude

%% Calculating Mach number

MachNumber = Speed / SoundSpeedVector(isAltitude);
A = asind(1 / MachNumber);

%% Displaying result
% using if else statments to classify the mach number

if MachNumber < 1
    fprintf("Subsonic MachNumber: %.2f\n", MachNumber)
elseif MachNumber == 1
    fprintf("Sonic MachNumber: %.2f\n", MachNumber)
elseif MachNumber > 1 && MachNumber <= 5
    fprintf("Supersonic MachNumber: %.2f MachAngle: %.0f\n", MachNumber, A)
else
    fprintf("Hypersonic MachNumber: %.2f\n", MachNumber)
end



