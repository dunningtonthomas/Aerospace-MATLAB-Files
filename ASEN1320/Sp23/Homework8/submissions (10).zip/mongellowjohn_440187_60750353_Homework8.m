load data.mat;

%initializes vectors for
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

%user inputs
Speed = input("Speed:");
Altitude = input("Altitude:");

tempVec = abs(AltitudeVector - Altitude); % subtracting altitude from all alt array valus

[M,isAltitude] = min(tempVec); % indexes the minimum altitude value location (closest to input altitude) as I

SoundSpeed = SoundSpeedVector(isAltitude); % finds sound speed at closest SoundSpeedVector value
MachNumber = Speed/SoundSpeed;
if(MachNumber < 1.0)
    Regime = 'Subsonic';
elseif(MachNumber == 1)
    Regime = 'Sonic';
elseif(MachNumber <= 5)
    Regime = 'Supersonic';
elseif(MachNumber > 5)
    Regime = 'Hypersonic';
end

%subsonic output
if(MachNumber < 1)
    fprintf('%s MachNumber: %.2f \n', Regime, round(MachNumber,2));
%supersonic output
elseif(MachNumber >=1)
    MachAngle = asind(1/MachNumber);
    fprintf('%s MachNumber: %.2f MachAngle: %.0f \n', Regime, round(MachNumber,2), round(MachAngle,0));    
end