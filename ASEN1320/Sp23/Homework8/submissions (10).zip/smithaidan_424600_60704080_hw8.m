load data.mat;
%load altitude, mach #, and speed of sound data

AltitudeVector = data(:,1);
%extract the first column of the data 

SoundSpeedVector = data(:,3);
%extract the third column of the data

%Speed = input("Speed: ");
%Altitude = input("Altitude: ");
%take user input for speed and altitude 

newvector = AltitudeVector - Altitude;
%subtract the altitude input from the vector

newvector = abs(newvector);
%take absolute value of the subtracted vector

[minval, isAltitude] = min(newvector);
%take the index of the minimum value, which is the value closest to the
%input and set it to isAltitude

Speedofsound = SoundSpeedVector(isAltitude);
%set speed of sound value to the indexed value based on input



MachNumber = Speed / Speedofsound;
%compute mach number and round to two decimal places;

if(MachNumber > 5)
      fprintf("Hypersonic MachNumber: %.2f\n", MachNumber);
      %output the number as a float rounded to two decimals

elseif(1 < MachNumber && MachNumber < 5)
    MachAngle = asind(1/MachNumber);
    fprintf("Supersonic MachNumber: %.2f MachAngle: %.0f \n", MachNumber, MachAngle);

elseif(MachNumber == 1)
    fprintf("Sonic MachNumber: %.2f\n", MachNumber);

elseif(MachNumber < 1)
    fprintf("Subsonic MachNumber: %.2f\n", MachNumber);


end