load data.mat

AltitudeVector = data(:,1);     %Altitude column
SoundSpeedVector = data(:,3);   %Sound Speed column

%User Input:
Speed = input("Speed: ");
Altitude = input("Altitude: ");

%Finding index of closest altitude value
normal = (AltitudeVector/Altitude)-1;
similar = abs(normal) == min(abs(normal));
isAltitude = find(similar);

%Finding speed of sound at closest altitutde
localSoundSpeed = SoundSpeedVector(isAltitude);

%Computing mach number
MachNumber = Speed / localSoundSpeed;

%Determining flight regime
if MachNumber < 1
    regime = "Subsonic";
elseif MachNumber == 1
    regime = "Sonic";
elseif 1 < MachNumber & MachNumber <=5
    regime = "Supersonic";
elseif MachNumber > 5
    regime = "Hypersonic";
end

%Printing results
if regime == "Supersonic"
    MachAngle = asind(1/MachNumber);
    fprintf ("%s MachNumber: %.2f MachAngle: %.f \n", regime, MachNumber, MachAngle)
else
    fprintf ("%s MachNumber: %.2f \n", regime, MachNumber)
end
