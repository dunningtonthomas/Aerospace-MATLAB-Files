load data.mat; %Loads data file
AltitudeVector = data(:,1); %Creates a column vector of the altitudes
SoundSpeedVector = data(:,3); %Creates a column vector of the speeds of sound

Speed = input('Speed:'); %Gets user input for the vehicle speed
Altitude = input('Altitude:'); %Gets user input for the vehicle altitude

isAltitude = findAltitudeIndex(Altitude, AltitudeVector); %Calls a user-defined function to find the index of the closest altitude to the input
MachNumber = Speed/SoundSpeedVector(isAltitude); %Calculates the mach number

%Conditional statements to output based on the mach number
if (MachNumber < 1.0)
        fprintf('Subsonic MachNumber: %.2f',MachNumber);

elseif(MachNumber == 1.0)
        fprintf('Sonic MachNumber: %.2f',MachNumber);

elseif (MachNumber > 1.0 && MachNumber <= 5.0)
        fprintf('Supersonic MachNumber: %.2f MachAngle: %i',MachNumber, calculateMachAngle(MachNumber));

elseif (MachNumber > 5.0)
        fprintf('Hypersonic MachNumber: %.2f',MachNumber);

end

%Function to calculate the mach angle in degrees
function [angle] = calculateMachAngle(machNumber)

angle = round((asin(1/machNumber))*180/pi);
end

%Function to find the index of the closest altitude value
function [index] = findAltitudeIndex(value,alts)
% Initializes a varible to store an index
index = 0;
% Iniitalizes a variable to store the smallest difference between value and the appropriate value in the loop
minDiff = realmax;
% For loop to iterate through the column vector alts
for i = 1:length(alts)
    diff = abs(value - alts(i)); %Computes the absolute difference between the value in alts and value
    %Stores the index of the smallest difference in index
        if (diff < minDiff)
            index = i;
            minDiff = diff;
        end
end
    
end
