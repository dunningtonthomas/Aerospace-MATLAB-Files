load data.mat %loads the data file data.mat 

AltitudeVector = data(:,1); % Assigns first column of data file to AltitudeVector
SoundSpeedVector = data(:,3); %Assigns third column of data file to SoundSpeed Vector 

Speed = input ("Speed:"); % requests a user input for speed and sets it to the Speed variable
Altitude= input ("Altitude:"); % requests a user input for Altitude and sets it to the Altitude variable 



a =interp1(AltitudeVector,AltitudeVector,Altitude,'nearest'); %Uses the interp1 function to find the closest value in Altitude vector to the value of Altitude 
isAltitude=find(AltitudeVector==a);% find the array index of the closest number found above 


MachNumber = (Speed/(SoundSpeedVector(isAltitude))); %calculates the mach number 

if (MachNumber<1)
fprintf('Subsonic MachNumber: %.2f\n', MachNumber);% if mach number is less than one will output this 

elseif(MachNumber==1)
fprintf('Sonic MachNumber: %.2f\n', MachNumber);% if mach number is equal to one will output this 

elseif(MachNumber>5)
fprintf('Hypersonic MachNumber: %.2f\n', MachNumber);% if mach number is greater than 5 will output this 
elseif(MachNumber>1) && (MachNumber<=5)
fprintf('Supersonic MachNumber: %.2f ', MachNumber); % if mach number is greater than one or less than/equal to five will output this and run the code below  

A=round(asind((1/MachNumber)));% calculates the mach angle and assigns it to the variable A 
fprintf('MachAngle: %.0f\n',A);% outputs mach angle 
end