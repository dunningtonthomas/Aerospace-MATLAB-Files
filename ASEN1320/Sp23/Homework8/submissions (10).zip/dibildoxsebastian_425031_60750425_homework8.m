load data.mat;
%^load the file with our information
%Using the file, take the entire 1st and 3rd column and seperate them into
%two arrays
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

%prompt user for input
Speed = input("Speed: ");
Altitude = input("Altitude: ");

%we use the (1D)interpolation function in order to find our user
%input(altitude) on a 1D line with X and Y values (both are the same, thus
%input X and V arguments are both AltitudeVector) and we want the function
%to search for the nearest altitude value
isAltitude = interp1(AltitudeVector, AltitudeVector, Altitude, "nearest");

%because i was too lazy to rename variables and didnt read the prompt,
%switch find the index of the nearest altitude, switch the altitude and the
%index
for i = 1:38
if AltitudeVector(i) == isAltitude
    AltPlaceholder = isAltitude;%placeholder is now equal to X altitude
    isAltitude = i;%is altitude now equals the index of X altitude
end
end

%using the index we found, find the speed of sound at that value using our
%other 1D array
SoundSpeed = SoundSpeedVector((isAltitude));
MachNumber = (Speed/SoundSpeed);%solve for the mach number

MachAngle = round(asind(1/MachNumber));%find mach angle for all cases
round(MachAngle, 1, "significant");%round said angle


%our conditional cascade to output whatever corresponds to mach number and
%angle
if MachNumber < 1
    fprintf('Subsonic MachNumber: %.2f\n', MachNumber)
elseif MachNumber == 1
    fprintf('Sonic MachNumber: %.2f\n', MachNumber)
elseif (MachNumber >1 && MachNumber <= 5)
    fprintf('Supersonic MachNumber: %.2f MachAngle: %.0f\n', MachNumber, MachAngle)
elseif MachNumber > 5
    fprintf('Hypersonic MachNumber: %.2f\n', MachNumber)
end




