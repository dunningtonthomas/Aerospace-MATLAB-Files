%Loading in data
load("data.mat");

%Assigning the data to vectors
AltitudeVector = data(:, 1);

SoundSpeedVector = data(:, 3);


%User Inputted Values
S = input("Speed: ");

Altitude = input("Altitude: ");

%Altitude and MachNumber
isAltitude = find(min(abs(AltitudeVector - Altitude)) == abs(AltitudeVector - Altitude));
MachNumber = S/SoundSpeedVector(isAltitude);

%Math and Computing Other Variables
FirstMachAngle = (180/pi)*asin(1/MachNumber);
MachAngle = round(FirstMachAngle);

%Determining the Speed

if MachNumber < 1
    fprintf("Subsonic MachNumber: %.2f \n", MachNumber)
end

if MachNumber == 1
    fprintf("Sonic MachnNumber: %.2f \n", MachNumber)
end

if 1 < MachNumber && MachNumber <= 5
    fprintf("Supersonic MachNumber: %.2f MachAngle: %d \n", MachNumber, MachAngle)
end

if MachNumber > 5
    fprintf("Hypersonic MachNumber: %.2f \n", MachNumber)
end