%loads the 2d array 'data' from data.mat

load('data.mat')

%initialize column vector AltitudeVector with 1st column of 'data'

AltitudeVector = data(:, 1);

%initialize column vector SoundSpeedVector with 3rd column of 'data'

SoundSpeedVector = data(:, 3);

%prompt user for vehicle speed value and assigns to variable Speed

Speed = input('Speed: ');

%prompt user for altitude value and assigns to variable Altitude

Altitude = input('Altitude: ');


% find index of AltitudeVector element value that matches altitiude value
% the most by using min. Assigns to variable isAltitude

[~, isAltitude] = min(abs(AltitudeVector - Altitude));

%Finds value of SoundSpeed at Altitude

SoundSpeed = SoundSpeedVector(isAltitude);

%Computes mach number by dividing the Speed and SoundSpeed. Assigned to
%variable MachSpeed

MachNumber = Speed/SoundSpeed;

%Use if else statements to check Machnumber affiliated flight regime


%Checks condition if MachNumber is less than 1. Outputs flight regime 'Subsonic' and
%Mach number value

if MachNumber < 1
    fprintf('Subsonic MachNumber: %.2f\n', MachNumber);

%Checks condition if MAchnumber is equal to 1. Outputs flight regime 'Sonic' and
%Mach number value

elseif MachNumber == 1
    fprintf('Sonic MachNumber: %.2f\n', Machnumber);

%Checks condition if MachNumber is less than 1 and greater or equal to 5.
%Also computes MachAngle in degrees
%Outputs flight regime 'Supersonic' and Mach number value
%Also outputs 'MachAngle' and its angle

elseif MachNumber > 1 && MachNumber <= 5
    MachAngle = (asin(1/MachNumber)) * (180/pi);
    fprintf('Supersonic MachNumber: %.2f MachAngle: %d\n', MachNumber, round(MachAngle));

%Checks condition if MachNumber is greater than 5. Outputs flight regime
%'Hypersonic' and Mach number value
else 
    fprintf('Hypersonic MachNumber: %.2f\n', MachNumber);

%end code
end 

