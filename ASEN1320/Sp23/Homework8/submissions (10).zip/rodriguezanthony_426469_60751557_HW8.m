load('data.mat'); %loads the file data.mat
%intializes the vectors
AltitudeVector = data(:,1); 
SoundSpeedVector = data(:,3); 

%Asks user to assign Speed and Altitude a Value using Input Functon
Speed = input('Speed: ');
Altitude = input('Altitude: ');
%This function finds us the Altitdue Vector that Matches our inputed Altitude
[~, isAltitude] = min(abs(AltitudeVector - Altitude));
%These Two functions find our SoundSpeed and MachNumber using the Previous Vector and A basic formula.
SoundSpeed = SoundSpeedVector(isAltitude);
MachNumber = Speed / SoundSpeed;
%The following checks if the Mach Number is less Than 1 and If true will output the Value with some text about the value.
if MachNumber < 1
    fprintf('Subsonic MachNumber: %.2f\n', MachNumber);
 %The following checks if the Mach Number is equal to 1 and If true will output the Value with some text about the value.
elseif MachNumber == 1
    fprintf('Sonic MachNumber: %.2f\n', MachNumber);
% The code below see if Mach Number is great than 1 and less than or equal to 5 then the code below will run. And MachAngle and Number will print.
elseif MachNumber > 1 && MachNumber <= 5
    % Computes The Mach Angle
    A = rad2deg(asin(1/MachNumber));
    fprintf('MachNumber: %.2f MachAngle: %d\n', MachNumber, round(A));
else
    %Does nothing then ends the program
end