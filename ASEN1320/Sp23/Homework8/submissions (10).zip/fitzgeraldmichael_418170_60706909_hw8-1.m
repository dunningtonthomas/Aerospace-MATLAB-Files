clc
clear

load data.mat; %loads the data file into MatLab

AltitudeVector = zeros(38, 1);  %sets an "empty" altitude array full of 0s
SoundSpeedVector = zeros(38, 1); %sets an "empty" speed array full of 0s

for x = 1:1:38 % sets AltitudeVector = to the 1st column of data
    AltitudeVector(x) = data(x, 1);
end

for y = 1:1:38  %sets SoundSpeedVector = to the 3rd column of data
    SoundSpeedVector(y) = data(y, 3);
end

Speed = input('Speed: ');  %asks for user input for variable "Speed"
Altitude = input('Altutide: '); %asks for user input for variable "Altitude"

isAltitude = AltitudeVector(1); %initially sets isAltitude = to the first element in AltitudeVector

for z = 1:1:37 %creates a for loop that increases isAltitude until the next value is farther away 
    
   
    if abs(AltitudeVector(z) - Altitude) > abs (AltitudeVector(z+1) - Altitude) %only sets isAltitude = to the next Altitude in AltitudeVector if it is closer than the next index 
        isAltitude = z+1;
        SoundSpeed = SoundSpeedVector(z+1); %sets the sound speed at the correct altitude
    end
end

MachNumber = Speed./SoundSpeed; %computes the Mach Number

if MachNumber<1 %sets cases for what flight regime the Mach Number falls into
    fprintf('Subsonic MachNumber: %.2f', MachNumber);
elseif MachNumber == 1 
    fprintf('Sonic MachNumber: %.2f', MachNumber);
elseif (1<MachNumber) && (MachNumber<=5)
    A = (asin(1./MachNumber)) .* (180./pi); %computes the mach angle and converts to degrees
    fprintf('Supersonic MachNumber: %.2f MachAngle: %.0f', MachNumber, A);
elseif 5<MachNumber
    fprintf('Hypersonic MachNumber: %.2f', MachNumber);
else 
end


