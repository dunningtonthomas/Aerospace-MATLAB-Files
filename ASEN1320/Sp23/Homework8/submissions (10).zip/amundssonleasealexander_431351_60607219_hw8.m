% Author: Alexander Amundsson-Lease
% Date: March 13, 2023
% Purpose: Take user input for aircraft speed and altitude, then return
%          mach regime, number, and angle.

% Load matrix data containing altitude and sound speed from data.mat
load data.mat;
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

% Take user input for aircraft speed and altitude
Speed = input('Speed: ');
Altitude = input('Altitude: ');

% Use find() function to determine the index of AltitudeVector that most
% closely matches the user input for aircraft altitude
isAltitude = find(min(abs(AltitudeVector - Altitude)) == abs(AltitudeVector - Altitude));

% Checking if there are two AltitudeVector values that are equally close to
% the user input, and omitting the smallest value if this is true 
% (rounding up).
if length(isAltitude) == 2
    isAltitude(1) = [];
end

% Calculating mach number using speed input and the determined index for
% SoundSpeedVector
MachNumber = Speed / SoundSpeedVector(isAltitude);

% Outputting mach regime and number that matches the calculated mach
% number. If regime is supersonic, the mach angle is also outputted.
if MachNumber < 1
    fprintf("Subsonic MachNumber: %.2f\n", MachNumber);
elseif MachNumber == 1
    fprintf("Sonic MachNumber: %.2f\n", MachNumber);
elseif MachNumber > 1 && MachNumber <= 5
    fprintf("Supersonic MachNumber: %.2f ", MachNumber);
    MachAngle = int8(asind(1 / MachNumber));
    fprintf("MachAngle: %d\n", MachAngle);
else
    fprintf("Hypersonic MachNumber: %.2f\n", MachNumber);
end