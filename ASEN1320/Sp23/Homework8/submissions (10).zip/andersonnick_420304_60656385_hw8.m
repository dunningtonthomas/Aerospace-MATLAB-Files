%Loading file
load('data.mat');

%Altitude in m
AltitudeVector = data(:,1);

%Temperature in C
Temperature = data(:,2);

%Speed of sound in m/s
SoundSpeedVector = data(:,3);

%User prompts
Speed = input('Speed: ');
Altitude = input('Altitude: ');

%Speed of sound at desired altitude
[~, isAltitude] = min(abs(AltitudeVector - Altitude));
sound = interp1(AltitudeVector, SoundSpeedVector, Altitude);

%MachNumber and MachAngle calculations
MachNumber = Speed / sound;

if MachNumber < 1
    MachNumber = floor(MachNumber * 100) / 100;
    fprintf('Subsonic MachNumber: %.2f\n', MachNumber);

elseif MachNumber == 1
    fprintf('Sonic MachNumber: %.2f\n', MachNumber);

elseif MachNumber > 5
    fprintf('Hypersonic MachNumber: %.2f\n', MachNumber);

elseif MachNumber > 1
    A = asind(1 / MachNumber);
    fprintf('Supersonic MachNumber: %.2f ', MachNumber);
    fprintf('MachAngle: %.0f\n', A);

end


