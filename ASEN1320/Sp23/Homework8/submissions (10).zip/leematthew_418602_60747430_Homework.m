
%load the data file
load ('data.mat');

%Initialize altitude and speed of sound vectors
AltitudeVector= data(:,1);
SoundSpeedVector = data(:,3);

%take user inputs for speed and altitude
%Speed = input('Speed:');
%Altitude = input('Altitude:');

%Find most similar altitude in AltitudeVector and assign to isAltitude
[~,isAltitude]=min(abs(AltitudeVector-Altitude));

%Find value of speed of sound w/altitude
S= data(isAltitude,3);

%find value of mach number
MachNumber= Speed/S;


%given the mach number, determine regime and output mach number or angle if
%supersonic 
if MachNumber<1
    fprintf('Subsonic MachNumber: %0.2f\n', MachNumber);
elseif MachNumber==1
    fprintf('Sonic MachNumber: %0.2f\n', MachNumber);
elseif MachNumber>1 && MachNumber<=5
    Angle=rad2deg(asin(1/MachNumber));
    fprintf('Supersonic MachNumber: %0.2f MachAngle: %0.0f\n', MachNumber,Angle );
else
    fprintf('Hypersonic MachNumber: %0.2f\n', MachNumber);
end








