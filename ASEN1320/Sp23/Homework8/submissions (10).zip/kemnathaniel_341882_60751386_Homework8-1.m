load data.mat;
altitudeVector=   data(:,1); 
SoundSpeedVector=  data(:,end); 
Speed = input('Speed: ');
Altitude = input('Altitude: ');
if Altitude ~= altitudeVector
while Altitude ~= altitudeVector
    Altitude= Altitude-1;
end
isaltitude= Altitude;
else 
    isaltitude= Altitude;
end
r = find(altitudeVector== isaltitude);
vSound=  SoundSpeedVector(r);
MachNumber= Speed/vSound; 
%switch MachNumber
    if MachNumber > 5
fprintf ('Hypersonic MachNumber: %.2f', MachNumber)
    elseif MachNumber <=5 && MachNumber >1
A = asin(1/MachNumber);
Angle= 180/pi*A;
Angle= int16 (Angle);
fprintf ('SuperSonic MachNumber: %.2f MachAngle: %d', MachNumber, Angle)
    elseif MachNumber == 1
fprintf ('Sonic MachNumber: %.2f', MachNumber)
    else 
fprintf ('Subsonic MachNumber: %.2f', MachNumber)
end



