%loading vector with data needed
load data.mat;

%turning individual columns in data into their own vectors
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

%asks for user input for speed and altitude and stores them as variables
Speed = input("Speed: ");
Altitude = input("Altitude: ");

%find what index of Altitude vector is closest to user input and stores it
Tempvec = AltitudeVector - Altitude;
[value, index] = min(abs(Tempvec));
isAltitude = index;

%uses stored index to find corresponding SoundSpeedVector value
MachNumber = Speed/SoundSpeedVector(isAltitude,1);

%calculates mach angle and turns into integer
MachAngle = asind(1 ./ MachNumber);
intMachAngle = cast(MachAngle,"int8");

%if else statement that outputs the class and machnumber based on
%calculated machnumber
if(MachNumber < 1)
    fprintf("Subsonic Machnumber: %.2f",MachNumber)
elseif(MachNumber == 1)
        fprintf("Sonic Machnumber: %.2f",MachNumber)
elseif(MachNumber > 1 && MachNumber <= 5)
        fprintf("Subsonic Machnumber: %.2f Mach Angle: %d",MachNumber,intMachAngle)
elseif(MachNumber > 5)
    fprintf("Hypersonic Machnumber: %.2f",MachNumber)
end


