close all;clc;clear;
load data.mat
AltitudeVector = data(:,1);           %Variable declaration
SpeedVector = data(:,3);              %User input
Speed = input("Speed: ");
Altitude = input("Altitude: ");

for i=1:length(AltitudeVector)

      if Altitude == AltitudeVector(i)
          IsAltitude = AltitudeVector(i);
          Altitude = IsAltitude;
          j = i;
      end
end
SoundSpeed = SpeedVector(i);


       %Equations to generate SoundSpeed and MachNumber


 MachNumber = Speed /SoundSpeed;

 
 %If statement to obtain the correct flow regime for each MachNumber
 if MachNumber < 1
   
    fprintf('Subsonic MachNumber: %f\n',  MachNumber);  
    
end

if MachNumber == 1
   
    fprintf('Sonic MachNumber: %f\n',  MachNumber); 
    
end

if (1 < MachNumber) && (MachNumber < 5)
   MachAngle = round(asind (1 / MachNumber));
     fprintf('Supersonic MachNumber: %f',MachNumber)
     fprintf(' MachAngle: %f\n',MachAngle)
      
     
end

if MachNumber > 5
   
    fprintf('Hypersonic MachNumber: %f\n',  MachNumber); 
    
    
end
