load 'data.mat';  %gets the data from the file data.mat and assigns it to a variable called data

AltitudeVector = zeros(38, 1);
SoundSpeedVector = zeros(38, 1);

for a = 1:1:38
    AltitudeVector(a) = data(a, 1);   %assigns all of the values in the first column of data to a varibale called Altitude Vector
end

for b = 1:1:38
    SoundSpeedVector(b) = data(b, 3);   %assigns all of the values in the third column of data to a varibale called SoundSpeedVector
end
 
Speed = input("Speed:"); %asks user to input a value for the speed variable
Altitude = input("Altitude:"); %asks user to input a value for the altitude variable

[d, e]=min(abs(AltitudeVector - Altitude)); %assigns the value in the altitudevector array that is closest to the
isAltitude = AltitudeVector(e);             %altitude vector entered by the user to the isAltitude variable

MachNumber = Speed/SoundSpeedVector(e);        %calculates MachNumber

MachAngle = asin(1/MachNumber); %Calculates Machangle in radians
MachAngle = MachAngle * 180/pi; %converts radians to angle

if MachNumber < 1
    fprintf('Subsonic MachNumber: %.2f \n' ,MachNumber)          %prints out machnumber as subsonic if it is below 1
elseif MachNumber == 1
    fprintf('Sonic MachNumber: %.2f \n' ,MachNumber)  %prints out machnumber as sonic if it equals 1
elseif (1 < MachNumber) && (MachNumber <= 5)           
    fprintf('Supersonic MachNumber: %.2f MachAngle: %.0f \n' ,MachNumber, MachAngle) %prints out machnumber as supersonic if it is between 1 and 5 and also prints mach angle
elseif 5 < MachNumber
    fprintf('Hypersonic MachNumber: %.2f \n' ,MachNumber)   %prints out machnumber as hypersonic if it is above 5
else
end

