load data.mat


% column vector 
AltitudeVector =data(:,1);

SoundSpeedVector =data(:,3);


% takes in the input variables for speed and altitude 
%Speed = ('Speed:');
%Altitude = ('Altitude:');

% all my calculations for the values 
tempAltitude = AltitudeVector  ==  Altitude;
isAltitude = AltitudeVector (tempAltitude);
MachNumber = Speed/Altitude;
MachAngle=asin(1/MachNumber);
MachNumber= round (MachAngle,2);
%% if statements 
%they all use fprintf and the values we had to compare them to

if (MachNumber < 1)
fprintf("Subsonic Mach Number: %.2f", MachNumber)
elseif (MachNumber == 1)
    fprintf("Sonic Mach Number %.2f", MachNumber) 
elseif ((MachNumber>1) <=5)
     fprintf("Supersonic Mach Number %.2f" ,MachNumber, MachAngle) 
elseif (5 < MachNumber)
     fprintf("Hypersonic Mach Number %.2f", MachNumber)
end