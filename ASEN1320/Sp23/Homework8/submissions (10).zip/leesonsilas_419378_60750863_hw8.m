load data.mat %load file into code

%Assigns vectors to certain column in data
AltitudeVector = data(:,1); 
SoundSpeedVector = data(:,3);

%Takes input from command window for speed and altitude
%Speed = input("Speed:"); 
%Altitude = input("Altitude:");

%Assigns altarr to the nearest data pints of both altitude vector and
%altitude
Altarr = interp1(AltitudeVector,AltitudeVector,Altitude,"nearest");

%sets isaltitude to the value weher altidue vector=altarr
isAltitude = find(AltitudeVector==Altarr);

%calculate machnumber and mach angle
MachNumber = Speed/SoundSpeedVector(isAltitude);
MachAngle = asind(1/MachNumber);

%if and elseif staements to test each possiblity and produce its output
if(MachNumber < 1)
    fprintf('Subsonic Machnumber: %.2f \n',MachNumber);
elseif(MachNumber == 1)
    fprintf('Sonic Machnumber: %.2f \n', MachNumber);
elseif(MachNumber <= 5)
    fprintf('Supersonic Machnumber: %.2f MachAngle: %f \n', MachNumber,MachAngle)
elseif(Machnumber > 5)
    fprintf('Hypersonic MachNumber: %f \n', MachNumber)
end