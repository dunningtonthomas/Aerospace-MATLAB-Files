close all; clear all; clc;

%loading data.mat
load data.mat;

%initializing vectors
Altitude1 = data(:, 1);
SoundSpeedVector = data(:, 3);

%prompting user
Speed = input("Speed: ")
Altitude = input("Altitude: ")

%indexing
[isAltitude, I] = min(abs(Altitude1 - Altitude));

%Mach
MachNumber = Speed/SoundSpeedVector(I);

%IF conditional statements
if (MachNumber < 1)
    fprintf("Subsonic MachNumber: %.2f \n",MachNumber);
elseif (MachNumber==1)
    fprintf("Sonic MachNumber: %.2f \n", MachNumber);
elseif (MachNumber > 1 && MachNumber <= 5)
    angle = asind(1/MachNumber);
    roundedangle = round(angle);
    fprintf("Supersonic MachNumber: %.2f", MachNumber);
    fprintf(" MachAngle: %.0f \n", roundedangle);
elseif (MachNumber > 5)
    fprintf("Hypersonic MachNumber: %.2f \n", MachNumber);
end















