load("data.mat");

AltitudeVector = data(:,1);%define altitude vec from data.mat
SoundSpeedVector = data(:,3);%define soundspeed vec from data.mat

Speed = input("Speed: ");%ask for user input for speed
Altitude = input("Altitude: ");%ask for user input for altitude

%defines isAltitude vector by taking the absolute value of the minimum of
%the altitude vector values minus the input value to declare isAltitude
[min_altitude_diff,isAltitude] = min(abs(AltitudeVector-Altitude));
SoundAtAlt=SoundSpeedVector(isAltitude);

MachNumber = Speed/SoundAtAlt;%calculate machnumber
MachAngle = asind(1/MachNumber);%calculate machangle

%if else sequence to output mach number and mach angle, only if it is
%supersonic speed
if (MachNumber < 1)
fprintf('Subsonic MachNumber: %.2f \n' ,MachNumber)
elseif(MachNumber == 1)
fprintf('Sonic MachNumber: %.2f \n' ,MachNumber)
elseif(1 < MachNumber <= 5)
fprintf('Supersonic MachNumber: %.2f MachAngle: %.f \n' ,MachNumber,MachAngle)
elseif(MachNumber > 5)
fprintf('Hypersonic MachNumber: %.2f \n' ,MachNumber)
end