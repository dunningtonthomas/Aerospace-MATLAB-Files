% clear the workspace and the command window
clc
clear

% Load the data file
load data.mat

% Assign the altitude and sound speed vectors to the first and third columns of data
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

Speed = input('Speed: ');
Altitude = input('Altitude: ');

% Find closest number to the altitude and assign it to temp, use temp 
% to find isAltitude
temp = interp1(AltitudeVector, AltitudeVector, Altitude, 'nearest');
isAltitude = find(AltitudeVector==temp);

% Use isAltitude and put it in the sound speed vector to find sound speed, then calculate
% MachNumber w/ sound speed and speed
SoundSpeed = SoundSpeedVector(isAltitude);
MachNumber = Speed/SoundSpeed;

% Calculate the angle and round it
MachAngleCalc = asind(1/MachNumber);
MachAngle = round(MachAngleCalc);

% If statements to determine the output
if (MachNumber < 1)
    fprintf("Subsonic MachNumber: %.2f\n", MachNumber)
end

if (MachNumber == 1)
    fprintf("Sonic MachNumber: %.2f\n", MachNumber)
end

if ((1 < MachNumber) && (MachNumber <= 5))
    fprintf("Supersonic MachNumber: %.2f MachAngle: %d\n", MachNumber, MachAngle)
end

if (MachNumber > 5)
    fprintf("Hypersonic MachNumber: %.2f\n", MachNumber)
end