%load data file and create matrixes out of altitude and speed of sound
%collums
load data.mat
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

%use inputs of plane speed and altitude
Speed = input("Speed: ");
Altitude = input("Altitude: ");

%find closest value of altitude
[M,isAltitude] = min(abs(AltitudeVector-Altitude));

%calculate machnumber
MachNumber = Speed /SoundSpeedVector(isAltitude);
MachNumber = round(MachNumber,2);

%calculate mach angle
A = ((asin(1 / MachNumber) * 180) / pi);
A = round(A,0);

%outputs to command window
if MachNumber < 1
    fprintf('Subsonic MachNumber: %.2f',MachNumber)
elseif MachNumber == 1
    fprintf("Sonic MachNumber: %.2f",MachNumber)
elseif MachNumber <= 5
    fprintf('Supersonic MachNumber: %.2f MachAngle: %d', MachNumber, A)
else
    fprintf('Hypersonic MachNumber: %.2f', MachNumber)
end