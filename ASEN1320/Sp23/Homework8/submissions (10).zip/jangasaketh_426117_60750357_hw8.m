% loads .mat files
load('data.mat')
% gets teh datat file and goes htorugh the first column and makes an array
% of that size
AltitudeVector =data(:,1);
% makes an array of the 3rd colum
SoundSpeedVector = data(:,3);
% promp allows me to get user input and store it into values
% matlab automatically converts any value into double
%Speed = input("Speed:");
%Altitude = input("Altitude:");

% matlab indexing starts at 1
i = 1;
% random r=number to compare difference to
number = 100000;
% this while loop uses not operator o compare values of Altitude and
% Altitude Vector and grabs the index

while (i<=length(AltitudeVector))
    diff = abs(AltitudeVector(i)-Altitude);
% the if statement here gets the difference and chooses the cloesest one to
% index
    if(diff<=number)
       number = diff;
       isAltitude = i;
    end
    i=i+1;
end

%using the index from the while loop, it collects the SoundSpedVector at
%that index
MachNumber = Speed/SoundSpeedVector(isAltitude);

% these comparioss allow me to comp
if (MachNumber<1)
    %formats it to two decimal places
    fprintf('Subsonic MachNumber: %.2f',MachNumber);
elseif (MachNumber == 1)
    fprintf('Sonic MachNumber: %.2f',MachNumber);
elseif ((MachNumber >1) && (MachNumber <= 5))
    % asind allows me to figure out Mach angle
    A = asind(1/MachNumber);
    fprintf('Supersonic MachNumber: %.2f',MachNumber)
    % converts it to an integer
    fprintf(' MachAngle: %d',round(A));
elseif (MachNumber > 5)
    fprintf('Hypersonic MachNumber: %.2f',MachNumber);

end



