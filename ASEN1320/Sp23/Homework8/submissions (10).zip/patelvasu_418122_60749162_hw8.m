close all; clear all; clc


load data.mat;
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

speed = input("Speed:");
altitude = input("Altitude:");

[isAltitude, J] = min(abs(AltitudeVector-altitude));

MachNumber = speed/SoundSpeedVector(J);

if(MachNumber < 1)
    fprintf("Subsonic MachNumber: %.2f \n", MachNumber);

elseif(MachNumber == 1)
    fprintf("Sonic MachNumber: %.2f \n", MachNumber);

elseif(MachNumber > 1 && MachNumber <= 5)
    fprintf("Supersonic MachNumber: %.2f ", MachNumber);
    MachAngle = asind(1/MachNumber);
    MachAngled = round(MachAngle);
    fprintf("MachAngle: %d \n", MachAngled)

elseif(MachNumber > 5)
     fprintf("Hypersonic MachNumber: %.2f \n", MachNumber);

end