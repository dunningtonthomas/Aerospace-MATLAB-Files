
load("data.mat");%loading mat file
AltitudeVector = data(:,1)% setting column = to altitude
SoundSpeedVector = data(:,3)% setting 3rd column = to sound speed
prompt = "Speed:";
Speed=input(prompt);
% asking for user input to get a speed and altitude
prompt2 = "Altitude:";
Altitude = input(prompt2);
%the user input subtracted from the Altitude vector gives isaltitude which
%is the closest value in the altitude column to the user altitude input
[min_altitude_diff,isAltitude] = min(abs(AltitudeVector - Altitude));
speedofsound = SoundSpeedVector(isAltitude);
MachNumber = Speed/speedofsound;%equation for mach number
machA = asind(1/MachNumber);% equation for mach angle 
%if mach number fits first critera it will output that statement if not it
%will go down each else if statement until it fits one of the criterias and
%will output the text in the quotes
if (MachNumber < 1)
    output = ('Subsonic MachNumber: %.2f \n');
    fprintf(output, MachNumber);

elseif (MachNumber == 1)
    output = ('Sonic MachNumber: %.2f \n');
    fprintf(output, MachNumber);

elseif ( 1 < MachNumber <= 5 )
    output = ('Supersonic MachNumber: %.2f MachAngle: %.f \n');
    fprintf(output, MachNumber,machA);

elseif (MachNumber > 5)
    output = ('Hypersonic MachNumber: %.2f \n');
    fprintf(output, MachNumber);

end











