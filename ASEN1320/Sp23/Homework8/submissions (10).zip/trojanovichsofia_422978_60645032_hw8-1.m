load data.mat %loading in data.mat

AltitudeVector = data(:, 1); %column vector w/ 1st column of data array
SoundSpeedVector = data(:, 3);

Speed = input("Speed: "); %take user input for Speed & Altitude 
Altitude = input("Altitude: ");  

%disp("AltitudeVector: ");
%disp(AltitudeVector); checking AltitudeVector and SoundSpeedVector

%disp("SoundSpeedVector: ");
%disp(SoundSpeedVector);

[~, isAltitude] = min(abs(AltitudeVector - Altitude));
%find index of AltitudeVector that matches user input for Altitude
%disp("isAltitude: "); disp(isAltitude);

SoundSpeed = SoundSpeedVector(isAltitude); %Find value of sound speed at
% user input 
%fprintf("SoundSpeed: %f\n", SoundSpeed);

MachNumber = Speed/SoundSpeed; %finding Mach Number
%fprintf("MachNumber: %f\n", MachNumber);


if MachNumber < 1 %if and ifelse statements for different output 
    fprintf("Subsonic MachNumber: %.2f", MachNumber)
elseif MachNumber == 1
    fprintf("Sonic MachNumber: %.2f", MachNumber)
elseif MachNumber > 1 && MachNumber <= 5
    MachAngle = round(asin(1/MachNumber)*180/pi);
    fprintf("Supersonic MachNumber: %.2f ", MachNumber)
    fprintf("MachAngle: %d", MachAngle)
elseif MachNumber > 5
    fprintf("Hypersonic MachNumber: %.2f", MachNumber) 
end



