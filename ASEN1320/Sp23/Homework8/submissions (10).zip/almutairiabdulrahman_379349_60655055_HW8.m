%Intiallizing Vector variables, and assigning them to a specifc column from
%the data file.
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

% Prompting user for Input: 
Speed = input("Speed:");
Altitude= input("Altitude:");

% Finding the closest Altitude value that matchs the most 
[~, isAltitude] = min(abs(AltitudeVector - Altitude));

%We got the number of rows from the isAltitude variable, then we use the
%3rd column to get the correct Soundspeed
SoundSpeed = SoundSpeedVector(isAltitude);

% Calculating Mach Number and the Angle from the given formulas
MachNumber = Speed / SoundSpeed;
Angle = asind ((1)/MachNumber);

% if/elseif statements to make sure we categorize each MachNumber
if (MachNumber<1)
    fprintf("Subsonic MachNumber: %.2f \n",MachNumber)

elseif(MachNumber == 1)
    fprintf ("Sonic MachNumber: %.2f\n", MachNumber)

elseif (MachNumber> 1 && MachNumber<=5)
    fprintf("Supersonic MachNumber: %.2f MachAngle: %.0f \n", MachNumber, Angle)


elseif (MachNumber<5)
fprintf("Hypersonic MachNumber: %.2f MachAngle: %.0f \n", MachNumber, Angle)

end