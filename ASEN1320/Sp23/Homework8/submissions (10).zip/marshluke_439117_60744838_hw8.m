load data.mat; %load data.mat

AltitudeVector = data(:,1); %set the altitude as all the values in data in the first column
SoundSpeedVector = data(:,3); %set the altitude as all the values in data in the third column

prompt1 = "Speed:";
Speed = input(prompt1);
prompt2 = "Altitude:";
Altitude = input(prompt2);
%Above takes the inputs of speed and altitude and assigns it to variables

A = interp1(AltitudeVector, AltitudeVector, Altitude,"nearest"); %
%above finds the number in altitudevector closest to the inputed altitude
isAltitude = find(AltitudeVector == A); %this finds the index of the altitude
Sounds = SoundSpeedVector(isAltitude,1); %uses the index to find the matching sound speed for that altitude

MachNumber = Speed/Sounds; %machnumber equation

if(MachNumber < 1)
    fprintf('Subsonic MachNumber:%.2f\n',MachNumber) 
    %display the mach number as subsonic if less than 1
else
    if(MachNumber==1)
        fprintf('Sonic MachNumber:%.2f\n',MachNumber)
        %display the machnumb if =1 as sonic
    else
        if(MachNumber > 1 && MachNumber <=5)
            A = asin(1/MachNumber); %find the arcsin of 1/machnumber
            D = rad2deg(A);%convert to degrees
            E = round(D);%round the degrees
            fprintf('Supersonic MachNumber:%.2f MachAngle:%d\n',MachNumber,E)
            %print the mach number as supersonic if >1 and <= 5 and display
            %the angle
        else
            if(MachNumber > 5)
                 fprintf('Hypersonic MachNumber:%.2f\n',MachNumber)
                 %if machnumber >5 it is hypersonic and display it
            end
        end
    end
end


