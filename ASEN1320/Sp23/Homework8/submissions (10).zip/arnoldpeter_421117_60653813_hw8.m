load("data.mat");

%initialization of variables 
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

Speed = input("Speed: ");
Altitude = input("Altitude: ");

%computes the minimum difference between "Altitude" and all of the 
%elements in the AltitudeVector and then returns the index of that 
%minimum
[min_altitude_diff,isAltitude]=min(abs(AltitudeVector-Altitude));

%sets the sound_speed_at_altitude = the corresponding SoundSpeedVector
%value using the index variable: isAltitude
Sound_Speed_at_Altitude=SoundSpeedVector(isAltitude);

%computes mach number
MachNumber=Speed/Sound_Speed_at_Altitude;

%computes mach angle in degrees
MachAngle=asind(1/MachNumber);

%if else branching statement with formatting
% I had to use the %x.xf format because %x.xd was giving me scientific
% notation
if MachNumber<1
    fprintf('Subsonic MachNumber: %3.2f',MachNumber)

elseif MachNumber == 1
    fprintf('Subsonic MachNumber: %3.2f',MachNumber)

elseif MachNumber >=1 && MachNumber <=5%the ".0" in %2.0f rounds MachAngle
    fprintf('Supersonic MachNumber: %3.2f MachAngle: %2.0f', ...
        MachNumber,MachAngle)

elseif MachNumber > 5
    fprintf('Hypersonic MachNumber: %3.2f',MachNumber)
end