%Homework #8
%Author: Clint Carafelli
%Purpose: To calculate the machnumber and in some cases the machangle based
%on a set of given values and user input values

%Load the given data in data.mat so it can be used in this script
load data.mat 

%Determining all values in the first column ofthe data file and storing 
%it into AltitudeVector
AltitudeVector = data(:,1); 

%Determining all values in the third column of the data file and storing 
%it into SoundSpeedVector
SoundSpeedVector = data(:,3); 

%Take user input for speed
Speed = input('Speed:'); 
%take user input for altitude
Altitude = input('Altitude:'); 

%Determine the difference
%between all the values in the altitude vector and the input altitude.
DifferenceVector = AltitudeVector - Altitude; 


%Find the minimum difference in altitude based on the absolute value and
%minimum function, storing the index of that value into isAltitude. This
%determines the closest altitude data point to the user input altitude
[value, isAltitude] = min(abs(DifferenceVector));

%Find the sound speed that matches the altitude data point
SoundSpeed = SoundSpeedVector(isAltitude); 

%Determine the machnumber
MachNumber  = Speed / SoundSpeed;

%Determine the machangle
MachAngle = asind(1/MachNumber);

%round the machangle to the nearest integer
IntMachAngle = round(MachAngle);

%If the machnumber is less than 1, display the mach number and that it is
%subsonic
if (MachNumber < 1)
    fprintf('Subsonic MachNumber: %.2f \n' ,MachNumber)

end

%If the machnumber is equal to 1, display the mach number and that it is
%sonic
if (MachNumber == 1)
    fprintf('Sonic MachNumber: %.2f \n', MachNumber)
    
end
%If the machnumber is less greater thann 1 but less than or equal to 5,
%display the machnumber, machangle, and that it is supersonic
if ((MachNumber > 1) && (MachNumber <= 5))
    fprintf('Supersonic MachNumber: %.2f MachAngle: %d \n', MachNumber, IntMachAngle)

end
%If the machnumber is greater than 5, display the machnumber and that it is
%hpyersonic
if (MachNumber > 5)
    fprintf('Hypersonic MachNumber: %.2f \n', MachNumber)

end



