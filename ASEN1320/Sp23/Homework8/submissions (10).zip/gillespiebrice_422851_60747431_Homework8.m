% Load data from data.mat file
load('data.mat');

% Prompt user for vehicle speed and altitude
Speed = input('Speed: ');
Altitude = input('Altitude: ');

% Initialize AltitudeVector and SoundSpeedVector
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3); 

% Find index of closest altitude in data
[~, isAltitude] = min(abs(AltitudeVector - Altitude));
% Compute Mach number
SoundSpeed = SoundSpeedVector(isAltitude);
MachNumber = Speed / SoundSpeed;

% Determine flight regime
if MachNumber < 1
    regime = 'Subsonic';
elseif MachNumber == 1
    regime = 'Sonic';
elseif MachNumber <= 5
    regime = 'Supersonic';
else
    regime = 'Hypersonic';
end

% If supersonic, compute Mach angle
if strcmp(regime, 'Supersonic')
    MachAngle = asin(1/MachNumber) * 180/pi; 
else
    MachAngle = NaN;
end

% Print results
if strcmp(regime, 'Supersonic')
    fprintf('Supersonic MachNumber: %.2f MachAngle: %.0f\n', MachNumber, MachAngle);
else
    fprintf('%s MachNumber: %.2f\n', regime, MachNumber);
end
