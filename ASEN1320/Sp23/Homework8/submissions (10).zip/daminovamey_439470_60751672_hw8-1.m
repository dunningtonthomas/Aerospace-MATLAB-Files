load data.mat; %loading data 
data;
AltitudeVector = data(:,1); %assign the first column to a variable
SoundSpeedVector = data(:, 3);%assign the third column to a variable

%take user input 
Speed = input('Speed: '); %Speed
Altitude = input('Altitude: '); %Altitude


[~, isAltitude] = min(abs(AltitudeVector - Altitude));
%storing the index after finding the matching values for Altitude in AltitudeVector
% ~ suppresses the first output, leaving only output for index 

MachNumber = Speed / SoundSpeedVector(isAltitude); %calculating the Mach number
MachAngle = round((asin(1/MachNumber))*180/pi); %calculating the Mach number

if MachNumber < 1
    fprintf('Subsonic MachNumber: %.2f\n',  MachNumber);
elseif MachNumber == 1
    fprintf('Sonic MachNumber: %.2f\n',  MachNumber);
elseif MachNumber>1 && MachNumber<=5
    fprintf('Supersonic MachNumber: %.2f MachAngle: %d\n',  MachNumber, MachAngle);
else 
    fprintf('Hypersonic MachNumber: %.2f\n',  MachNumber);
end






