%Housekeeping while working on assignment
%clear
%clc

%Opens the data file
load data.mat;


%Sets altitude vector as the first column of the data matrix
AltitudeVector = data(:,1);

%Sets speed vector as the third column of the data matrix
SoundSpeedVector = data(:,3); 

%Prompts the user to input speed
Speed = input('Speed: ');

%Prompts the user to input Altitude
Altitude = input('Altitude: ');


%Finds the absolute difference between the entered altitude
AltDifVector = abs(AltitudeVector - Altitude);

%Sets a very large number equal to the value that will be compared so that
%the variable will always change to the first 
MinimumDifference = 1000000000;

%This was a for loop used to find what the closest altitude to the given input is. It
%does so by comparing all of the values of the absolute difference vector.
%Whatever the lowest value of the absolute difference vector is, it finds
%the index of that vector
% for i = 1:length(AltDifVector)
%    if (AltDifVector(i) < MinimumDifference)
%        MinimumDifference = AltDifVector(i);
%        Index = i;
%    elseif (AltDifVector(i) == MinimumDifference)
%        Index = i - 1;
%    end
% end

%More optimized way of finding the Index of the the closest element
[MinimumDifference, Index] = min(AltDifVector);

%Sets isAltitude to the closest value in the altitude vector
isAltitude = Index;

%Finds the Mach Number
MachNumber = Speed / SoundSpeedVector(Index);


%If and elseif conditional statement to output what regime the aircraft is
%in
if (MachNumber < 1)
    fprintf('Subsonic MachNumber: %.2f \n', MachNumber);
elseif (MachNumber == 1)
    fprintf('Sonic MachNumber: %.2f \n', MachNumber);
elseif ((1 < MachNumber) && (MachNumber <= 5))
    MachAngle = int32((asin(1 / MachNumber) * 180 / pi));
    fprintf('Supersonic MachNumber: %.2f MachAngle: %d \n', MachNumber, MachAngle);
else
    fprintf('Hypersonic MachNumber: %.2f \n', MachNumber);
end