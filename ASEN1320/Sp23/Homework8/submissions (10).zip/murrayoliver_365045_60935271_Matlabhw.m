
load data.mat
AltitudeVector = data(:,1);
SoundSpeedVector=data(:,3);

Speed = input('Speed: ');
Altitude = input('\nAltitdue: ');



 differencevector= abs(AltitudeVector-Altitude);
[M,isAltitude] =min(differencevector);
SpeedSound = SoundSpeedVector(isAltitude);
MachNumber=Speed/SpeedSound;
A =(asind(1/MachNumber));
B = round(A);
 if MachNumber<1
fprintf('Subsonic MachNumber: %.2d',MachNumber)
 else if MachNumber ==1
         fprintf('Sonic MachNumber: %.2d',MachNumber)
 else if 1<MachNumber<=5
fprintf('Supersonic MachNumber: %.2d Machangle: %i',MachNumber,B)
 else if 5<MachNumber
         fprintf('Hypersonic MachNumber: %.2d',MachNumber)
 else
 end
 end
 end
 end