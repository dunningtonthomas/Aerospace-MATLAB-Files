% Mach number is given by M = V/S
% V is vehicle speed
% S is the speed of sound

% Mach angle is A = arcsin(1/M)


load data.mat % load entire data file

AltitudeVector = data(:,1); % define altitude column vector and grab info from data.mat
SoundSpeedVector = data(:,3); % define sound speed column vector and grab info from data.mat

Speed = input("Speed: "); % input speed
Altitude = input("Altitude: "); % input altitude

% Check most closely matched Altitude value to get index for sound speed
difference = abs(AltitudeVector - Altitude);
[~, isAltitude] = min(difference);
SoundSpeed = SoundSpeedVector(isAltitude);


% Calculate MachNumber, MachAngle and convert MachAngle to int
MachNumber = Speed/SoundSpeed;
MachAngle = asind(1/MachNumber);
intMachAngle = int32(MachAngle);

% if else statement checking/comparing magnitude of MachNumber for
% respective output
if (MachNumber < 1)
    fprintf('Subsonic MachNumber: %.2f', MachNumber);
elseif (MachNumber == 1)
    fprintf('Sonic MachNumber: %.2f', MachNumber);
elseif ((1 < MachNumber) && (MachNumber <= 5))
    fprintf('Supersonic MachNumber: %.2f MachAngle: %i', MachNumber, intMachAngle);
else
    fprintf('Hypersonic MachNumber: %.2f', MachNumber);
end