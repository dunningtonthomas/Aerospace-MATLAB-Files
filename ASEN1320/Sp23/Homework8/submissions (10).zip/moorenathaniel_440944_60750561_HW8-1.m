% Program to run HW8

% Author: Moore
% Date: 17 Mar 2023

% Load data.mat array to workspace
load data.mat

% Initialize column vectors from appropriate columns of data array
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

% Dispaly assigned messages along with initialized prompted user input
Speed = input('Speed: ');
Altitude = input('Altitude: ');

% Create logical vector to index AltitudeVector from loaded column vectors that closest matches 
% user input. This rounds down to closeset value in the case that user input is
% between values.
logicalVec = AltitudeVector <= Altitude;
isAltitude = find(logicalVec,1,'last');

% Indexed Altitude vector is used to index appropiate SoundSpeed vector
SoundSpeed = SoundSpeedVector(isAltitude);

% MachNumber calculated
MachNumber = Speed/SoundSpeed;

% If/Elseif statements created. Proper output displayed depending on
% statement parameters
if(MachNumber < 1)
    fprintf("Subsonic MachNumber: %.2f \n", MachNumber);

elseif(MachNumber == 1)
    fprintf("Sonic MachNumber: %.2f \n", MachNumber);

% MachAngle is calculated and displayed if MachNumber falls within specified parameters
elseif((1 < MachNumber) && (MachNumber <=5))
    angle = asin(1/MachNumber);
    MachAngle = round(angle*180/pi,0);
    fprintf("Supersonic MachNumber: %.2f MachAngle: %d \n", MachNumber, MachAngle);

else( 5 < MachNumber);
    fprintf("Hypersonic MachNumber: %.2f \n", MachNumber);

end % End of program



