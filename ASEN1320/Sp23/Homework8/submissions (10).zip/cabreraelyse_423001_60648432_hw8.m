load data.mat %load file

%set vectors to their respective columns in data
AltitudeVector = data(:, 1); 

SoundSpeedVector = data(:, 3);

%user input and assigns to values
Speed = input("Speed: ");
Altitude = input("Altitude: ");

%find index of value in altitudevector closest to input altitude
isAltitude = find(min(abs(AltitudeVector - Altitude)) == abs(AltitudeVector - Altitude));
MachNumber  = Speed/SoundSpeedVector(isAltitude); %calculates machnumber

if (MachNumber < 1)
    fprintf('Subsonic MachNumber: %.2f\n',MachNumber) %statement prints if conditions are satisfied, machnumber outputed with 2 decimals


elseif (MachNumber == 1)
    fprintf('Sonic MachNumber: %.2f\n',MachNumber) %statement prints if conditions are satisfied, machnumber outputed with 2 decimals


elseif (MachNumber > 1 && MachNumber <= 5)
    angle = (180/pi)*asin(1/MachNumber); %calculate mach angle and convert to degrees
    MachAngle = round(angle); %round double result to nearest degree
    fprintf('Supersonic MachNumber: %.2f MachAngle: %d\n', MachNumber, MachAngle) %statement prints if conditions are satisfied, machnumber outputed with 2 decimals and machangle as integer

else
    fprintf('Hypersonic MachNumber: %.2f\n', MachNumber) %statement prints if conditions are satisfied, machnumber outputed with 2 decimals
end


