% importing data file
load("data.mat")

% initializing vectors
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

% asking for speed and altitude vectors
Speed = input("Speed:");
Altitude = input("Altitude:");

% calculating values

%finding the smallest difference of each value in vector
%finding the index of that value
[~, isAltitude] = min(abs(AltitudeVector-Altitude));
MachNumber = Speed/SoundSpeedVector(isAltitude); 

MachAngle = asin(1/MachNumber)*180/pi; % finding angle and converting it to degrees

if MachNumber < 1
    fprintf("Subsonic Machnumber: %.2f\n", MachNumber); %('%.2f', MachNumber); %  %.2f rounds to 2 decimal places including zeros
elseif MachNumber == 1
    fprintf("Sonic MachNumber: %.2f\n", MachNumber);
elseif MachNumber <=5
    fprintf("Supersonic MachNumber: %.2f MachAngle: %d\n", MachNumber, round(MachAngle)); %round() turns machangle into an int sub
else 
    fprintf("Hypersonic MachNumber: %.2f %d\n", MachNumber);
end 
