load data.mat %loads the given array of values 
AltitudeVector = data(:,1); %makes an altitude array out of the first column of the data array
SoundSpeedVector = data(:,3); %makes sound speed array from third column of data array

%prompts for user input
Speed = input('Speed: ');
Altitude = input('Altitude: ');

%finds the place where the input altitude is closest to value in array
[minval,index] = min(abs(AltitudeVector - Altitude));

%takes the index of the closest altitude value
isAltitude = index;

%calculates the mach number at that altitude
MachNumber = Speed / SoundSpeedVector(isAltitude);

%shows sonic level and mach number with two decimal places
if (MachNumber < 1)
    fprintf('Subsonic MachNumber: %.2f \n',MachNumber)
elseif (MachNumber == 1)
    fprintf('Sonic MachNumber: %.2f \n', MachNumber)
elseif (MachNumber > 1 && MachNumber <= 5)
    MachAngle = round(asin(1 / MachNumber) * 180 / pi); %calculates mach angle as an integer
    fprintf('Supersonic MachNumber: %.2f MachAngle: %d \n', MachNumber, MachAngle)
else
    fprintf('Hypersonic MachNumber: %.2f \n', MachNumber)
end
