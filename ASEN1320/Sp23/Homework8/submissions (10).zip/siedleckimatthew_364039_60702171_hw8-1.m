% loads the data file we will use for rest of code
load data.mat;
% pulls the first column from the data file and turns it into new matrix
AltitudeVector = data(:,1);
%% pulls the third column from the data file and turns it into new matrix
SoundSpeedVector = data(:,3);
% prompts user to input speed
Speed = input("Speed: " );
% prompts user to input altitude
Altitude = input("Altitude: ");
% Finds the smallest difference between preset altitude values and user
% inputed altitude
DifferenceVector = abs(AltitudeVector - Altitude);
% Finds the closest altitude to the user inputed altitude
[M,isAltitude] = min(DifferenceVector);
% Finds the speed of sound associated with altitude found on last line
SpeedSound = SoundSpeedVector(isAltitude);
%Calculates our Machnumber 
MachNumber = Sound/SpeedSound;
%Calculates our Machangle
MachAngle = round(asind(1/MachNumber));

%% The rest of these lines of code take our machnumber and find if it is less than 1, 
% equal to 1, inbetween 1 and 5, or greater than 5 and gives an output
% based on that. The machangle is only outputed for a machnumber between
% 1 and 5. 

 if (MachNumber <1)
 fprintf("Subsonic Machnumber: %.2f,",MachNumber);
 elseif (MachNumber == 1)
    fprintf("Sonic Machnumber: %.2f", MachNumber);
elseif (MachNumber > 1 && MachNumber <=5)
    fprintf("Supersonic Machnumber: %.2f MachAngle: %d",MachNumber,MachAngle);
elseif (MachNumber > 5)
fprintf("Hypersonic Machnumber: %.2f",MachNumber);
else
end