%Load data from file 
load("data.mat");  

%Extract two columns of data into different vectors 
AltitudeVector = data(:,1);
SoundSpeedVectore = data(:,3);

%Take user input for Speed and Altitude 
Speed = input("Speed: ");
Altitude = input("Altitude: ");

% Calculate the index of the closest altitude in the AltitudeVectorto the user input Altitude
x = AltitudeVector - Altitude;

[~,isAltitude] = min(abs(x));

% Use the isAltitude index to get the corresponding SoundSpeed value from the SoundSpeedVector
SoundSpeed = SoundSpeedVector(isAltitude);

%Calculating mach number using user input and data from file 
MachNumber = Speed / SoundSpeed;

%using if and else if statements determining the range of the mach number 
%based on it value we calculated and print out a message to the console
if(MachNumber < 1)
    fprintf("Subsonic MachNumber: %.2f", MachNumber);
elseif(MachNumber == 1)
    fprintf("Sonic MachNumber: %.2f", MachNumber);
elseif(MachNumber <=5 )
     MachAngle = asin(1/MachNumber) * 180/pi;
    fprintf("SuperSonic MachNumber: %.2f HyperSonic MachNumber: %.f", MachNumber, MachAngle);
else %(MachNumber > 5)
    fprintf("HyperSonic MachNumber: %.2f", MachNumber);


end



