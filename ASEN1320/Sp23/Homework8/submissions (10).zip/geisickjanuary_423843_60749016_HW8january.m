% This loads data.mat so its values can be used in the program
load data.mat


% This makes a new array with the entire 1st column of values from data.mat
AltitudeVector = data(:,1);
% This makes a new array with the entire 3rd column of values from data.mat
SoundSpeedVector = data(:,3);


% This creates a new variable "speed" and asks for a value with the 
% prompt "Speed: "
speed = input('Speed: ');
% This creates a new variable "altitude" and asks for a value with the 
% prompt "Altitude: "
altitude = input('Altitude: ');


% This creates an array that contains a 1 if altitude is greater than the
% vector value, and a 0 if the altitude variable is smaller
logicalVec = AltitudeVector <= altitude;
% This cuts down the vector to only have indexes with a 1 remain
limitedaltitude = find(logicalVec);
% This creates a variable whose value is the number of indexes from limited
% altitude. This way we can now get other values from our data at the level
% where our altitude is.
dataindex = max(limitedaltitude);
% Here we set our speed of sound equal to the speed of sound we get from
% the data near our inputted altitude.
SoundSpeed = SoundSpeedVector(dataindex);


% This calculates our MachNumber given a craft velocity and local 
% speed of sound
MachNumber = speed/SoundSpeed;
% This calculates the MachAngle for a given MachNumber and outputs it in 
% degrees instead of radians
angle = asind(1/MachNumber);

% if the craft is subsonic we output the subsonic Machnumber
if (MachNumber < 1) 
    fprintf('Subsonic MachNumber: %.2f \n' ,MachNumber)

% if the craft is sonic we output the sonic Machnumber
elseif (MachNumber == 1) 
    fprintf('Sonic MachNumber: %.2f \n' ,MachNumber)

% if the craft is hypersonic we output the hypersonic Machnumber
elseif (MachNumber > 5) 
    fprintf('Hypersonic MachNumber: %.2f \n' ,MachNumber) 

% if the craft is not sonic, subsonic, or hypersonic, it must be 
% supersonic, so we output supersonic Machnumber
else 
    fprintf('Supersonic MachNumber: %.2f MachAngle: %.0f \n' ,MachNumber,angle)

end







