
clear
clc
load data.mat

%column vector Altitude Vector
AltitudeVector = [data(:, 1)];

%column vector sound speed vector
SoundSpeedVector = [data(:, 3)];

%prompt user for vehicle speed and altitude
Speed = input('Speed:');
Altitude = input('Altitude:');

%calculating the isAltitude, the closest altitude in altitude vector from
%user input
tempAltitude = interp1(AltitudeVector, AltitudeVector, Altitude, "nearest");
isAltitude = find(tempAltitude==AltitudeVector);

%computing the soundspeed from the table
soundSpeed = SoundSpeedVector(isAltitude);

%computing the mach ratio
MachNumber = Speed/soundSpeed;

%logic to return data based on the resulting mach rato
if MachNumber < 1
    fprintf("Subsonic MachNumber: %.2f\n", MachNumber)
elseif MachNumber == 1
    fprintf("Sonic Machnumber: %.2f\n", MachNumber)
elseif MachNumber>1 && MachNumber<=5
    machAngle = round(asind(1/MachNumber)); %need to turn from radians to angle
    fprintf("Supersonic MachNumber: %.2f MachAngle: %d\n", MachNumber, machAngle)
elseif MachNumber > 5
    fprintf("Hypersonic MachNumber: %.2f\n", MachNumber)
end
