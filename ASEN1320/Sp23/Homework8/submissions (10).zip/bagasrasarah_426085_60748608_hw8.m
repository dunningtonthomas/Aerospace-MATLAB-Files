clear %clears Command Window - removes all varibles and clear them from memory
clc %clears workspace
load data.mat %loads file data.mat and stores the arrays
AltitudeVector = data(:,1); % contains all elements from first column of data
SoundSpeedVector = data(:,3); % contains all elements from 3rd column of data 
Speed = input('Speed: '); % prompts user for speed input by outputing to terminal Speed:
Altitude = input('Altitude: '); % prompts user for altitude input by outputing Altitude: to terminal
NearestAltitude = interp1(AltitudeVector,AltitudeVector,Altitude,'nearest'); % using the interp1 function, finds the value closest to inputed Altitude in Altitude Vector Array, saves the nearest altitude found to NearestAltitude 
isAltitude = find(AltitudeVector == NearestAltitude); % takes the NearestAltitude (found in line 9) and uses the find function to find the index (row number) of the NearestAltitude 
%disp(isAltitude); ignore - was for testing purposes
SSV = SoundSpeedVector(isAltitude); % SSV stands for soundspeedvalue, finds value of SVV using isAltitude, isAltitude is the index number of NearestAltitude, finds the value of the SoundSpeed at that index
%disp(SSV); ignore - was for testing purposes
mnumber = (Speed/SSV); % this is the calculation for the MachNumber, I find it but save it to mnumber
MachNumber = round(mnumber,2); % this rounds the calculated mnumber and saves it as MachNumber
%disp(MachNumber);% ignore :)
A = asin(1/MachNumber); % finds the angle
Angle = round(A,1); % rounds the angle to the first decimal place... i was having trouble with getting the output to be exact and I realized it was a decimal and rounding issue so my solution was to round it to the first decimal place
D = rad2deg(Angle); % converts angle from radians to degrees and saves it as D
MachAngle = round(D,0); % MachAngle is the degrees rounded to the nearest whole number

%below are my if and else if statements
if(MachNumber < 1) %if MachNumber is less than 1...
    fprintf('Subsonic MachNumber: %.2f \n', MachNumber); %output to consol/commandwindow Subsonic MachNumber, %.2f is the MachNumber and is linked to it the ,MachNumber tells it that %.2f is the calculated number
elseif(MachNumber == 1) %else if statement, if it's not less than 1 but is equal to 1 do this...
    fprintf('Sonic MachNumber: %.2f \n', MachNumber); %output Sonic MachNumber  %.2f is the MachNumber and is linked to it the ,MachNumber tells it that %.2f is the calculated number
elseif(MachNumber > 1 && MachNumber <=5) %another else if statement, if 1 < MachNumber <= 5, then....
    fprintf('Supersonic MachNumber: %.2f MachAngle: %d', MachNumber, MachAngle); %output to consol Supersonic MachNumber and MachAngle, %d linked to MachAngle
elseif(MachNumber > 5) %last else if, it could also have been an else but it gave me the warning symbol and I didn't like that so I made it an else if, MachNumber is greater than 5
    fprintf('Hypersonic MachNumber: %.2f', MachNumber); % outputs to consol Hypersonic MachNumber,
end %ends all the if statements
