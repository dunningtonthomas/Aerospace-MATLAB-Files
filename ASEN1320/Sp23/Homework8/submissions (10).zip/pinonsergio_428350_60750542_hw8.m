load data.mat;
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);
Speed = input('Speed: ');
Altitude = input('Altitude: ');
[~, isAltitude] = min(abs(AltitudeVector-Altitude));

MachNumber = Speed/SoundSpeedVector(isAltitude);
if MachNumber < 1
    speedtype = 'Subsonic';
elseif MachNumber == 1
    speedtype = 'Sonic';
elseif MachNumber <= 5
    speedtype = 'Supersonic';
else
    speedtype = 'Hypersonic';
end
disp(['Speed: ' num2str(Speed)]);
disp(['Altitude: ' num2str(Altitude)]);
if MachNumber > 1 && MachNumber <= 5
    A = asin(1/MachNumber)*180/pi;
    MachNumber = round(MachNumber,2);
    A=round(A);
   disp([speedtype ' Mach number : ' num2str(MachNumber) ' Mach angle : ' num2str(A) ' degrees']);

else
    MachNumber = round(MachNumber,2);
    disp([speedtype ' Mach number : ' num2str(MachNumber)]);
end

