%Author: Brandon Lee
%Date March 13, 2023

load data.mat; %Loading in data matrix

AltitudeVector = data(:,1); %Creating a column vector for the first column of data

SoundSpeedVector = data(:,3); %Creating a column vector for the third column of data

Speed = input("Speed: "); %Taking user input for vehicle speed

Altitude = input("Altitude: "); %Taking user input for altitude

isAltitude = find(AltitudeVector <= Altitude, 1, 'last'); %Finds the index of AltitudeVector closest to the users input for altitude


MachNumber = Speed / SoundSpeedVector(isAltitude); %Calculating MachNumber by taing the same index of the AltitudeVector and applying it to the SoundSpeed vector to divide by Speed

if (MachNumber < 1) %If statement used to differentiate between different flight regimes depending on the MachNumber
    fprintf("Subsonic MachNumber: %.2f \n", MachNumber)
elseif (MachNumber == 1)
    fprintf("Sonic MachNumber: %.2f \n", MachNumber)
elseif (MachNumber > 1 && MachNumber <= 5)
    A = asin(1/MachNumber)*180/pi; %Calculates the MachAngle and converts it from radians to degrees
    fprintf("Supersonic MachNumber: %.2f MachAngle: %.0f \n", MachNumber, A)
else
    fprintf("Hypersonic MachNumber: %.2f \n", MachNumber)
end




