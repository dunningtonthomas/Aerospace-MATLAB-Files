load data.mat;
AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

Speed = input("Speed:");

Altitude = input("Altitude:");

alt = interp1(AltitudeVector,AltitudeVector,Altitude,"Nearest");
isAltitude = find(AltitudeVector == alt);

MachNumber = Speed/SoundSpeedVector(isAltitude);
MachAngle = asind(1/MachNumber);
if(MachNumber < 1)
fprintf("Subsonic MachNumber: %.2f",MachNumber)
elseif(MachNumber == 1)
fprintf("Sonic MachNumber: %.2f",MachNumber)
elseif(MachNumber <= 5)
fprintf("Supersonic MachNumber: %.2f MachAngle: %f",MachNumber,MachAngle)
elseif(MachNumber > 5)
fprintf("Hypersonic MachNumber %f", MachNumber)
end


