clear;
clc;

load data.mat

%Assigns column 1 of data to AltitudeVector
AltitudeVector = [data(1:end, 1)];

%Assigns column 3 of data to SoundSpeedVector
SoundSpeedVector = [data(1:end, 3)];

%Asking for user input for speed and altitude
Speed = input("Speed: ");
Altitude = input("Altitude: ");

%This is the length of the vector.
i = length(AltitudeVector);

%Looks for a value close to the inputed altitude in AltitudeVector
for N = 1:i
    if Altitude >= AltitudeVector(N,1)
        isAltitude = N;
    end
end

%Finding a value of SoundSpeed at index N
SoundSpeed = SoundSpeedVector(isAltitude,1);

%Computing the Mach Number
MachNumber = Speed / SoundSpeed;
%Computing the Mach Angle
MachAngle = asind(1 / MachNumber);

%Output
if MachNumber < 1
    fprintf('Subsonic MachNumber: %.2f\n',MachNumber)
elseif MachNumber == 1
    fprintf('Sonic MachNumber: %.2f\n',MachNumber)
elseif MachNumber > 1 & MachNumber <= 5
    fprintf('Supersonic MachNumber: %.2f MachAngle: %d\n',MachNumber,round(MachAngle))
elseif MachNumber > 5
    fprintf('Hypersonic MachNumber: %.2f\n',MachNumber)
end


