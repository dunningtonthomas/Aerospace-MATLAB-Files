load data.mat;  %loads data file
AltitudeVector = data(:,1); %Creates vector named AltitudeVector from first column of data file
SoundSpeedVector = data(:,3);   %Creates vector named SoundSpeedVector from third column of data file
Speed = input(Prompt); %takes user input for speed
Altitude = input(Prompt2); %takes user input for altitude
[val,idx] = min(abs(AltitudeVector-Altitude));  %takes user input and indexes AltitudeVector to find the value in the vector that is closest to the input
closestAltitude = AltitudeVector(idx); 
isAltitude = find(AltitudeVector==closestAltitude); %isAltitude is the location that the finding the closest value gives you
Aspeed = SoundSpeedVector(isAltitude, 1);   %Finds the speed of sound at the altitude that was calculated
disp(Aspeed);   %displays the speed of sound calculated
MachNumber = Speed/Aspeed;  %calculates machnumber from input speed and speed of sound at given altitude
MachAngle = int16(asind(1/MachNumber)); %calculates mach angle from mach number
if (MachNumber < 1)
    fprintf ('Subsonic MachNumber: %.2f \n' ,MachNumber)    %outputs regime and mach number depending on the mach number
elseif (MachNumber == 1)
    fprintf ('Sonic MachNumber: %.2f \n' ,MachNumber)
elseif (MachNumber > 5)
    fprintf ('Hypersonic MachNumber: %.2f \n' ,MachNumber)
else
    fprintf ('Supersonic MachNumber: %.2f MachAngle: %i \n' ,MachNumber, MachAngle) %outputs mach angle if mach number is greater than 5.
end