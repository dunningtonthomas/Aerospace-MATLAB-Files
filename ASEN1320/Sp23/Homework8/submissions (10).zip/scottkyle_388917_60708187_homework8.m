%Homework 8
%Changed V to Speed on MATLAB grader
clear
clc
load data.mat
AltitudeVector = data(:,1); %creating vectors, Altitude skips rows and stores column 1
SoundSpeedVector = data(:,3);  % storing column 3

V = input("Speed: ")   %user input
Altitude = input("Altitude: ")

isAltitude = interp1(AltitudeVector,1:length(AltitudeVector),Altitude,'nearest'); % finding where the nearest Altitude data value is on data.mat
S = SoundSpeedVector(isAltitude); % using that altitude position to find corresponding 3rd column value

MachNumber = V/S; % rounding and calculations (also converting angle from radians to degrees, THEN rounding)
Number = round(MachNumber,2);
MachAngle = asin((1 / MachNumber));
AngleR = rad2deg(MachAngle);
Angle = round(AngleR);

if(MachNumber < 1)  % required conditional statements that use MAchNumber's value to determine the output
    sprintf("Subsonic MachNumber:%d", Number)
elseif(MachNumber ==1)
    sprintf("Sonic MachNumber: %d", Number)
elseif((1 < MachNumber) && (MachNumber <= 5))
    sprintf("Supersonic MachNumber:%d MachAngle: %f", Number, Angle)
elseif(5<MachNumber)
    sprintf("Hypersonic MachNumber: %d", Number)
end
