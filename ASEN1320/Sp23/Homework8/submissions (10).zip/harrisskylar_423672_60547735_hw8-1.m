clc
clear

load data.mat; %loads in data matrix (2D array)

AltitudeVector = data(:,1); %altitude vector is the 1st column in array
SoundSpeedVector = data(:,3); %sound speed vactor is 3rd/last column in array

Speed = input('Speed: '); %prompt with user input for speed
Altitude = input('Altitude: '); %prompt with user input for altitude

[val,isAltitude] = min(abs(AltitudeVector-Altitude)); %finds closest value in altitude vector to altitude value and assigns index of that value to isAltitude

SoundSpeed = SoundSpeedVector(isAltitude); %finds value from sound speed vector with same index as altitude vector and assigns it to variable

MachNumber = Speed/SoundSpeed; %computes mach number

if (MachNumber < 1) %executes if mach number is less than 1
    fprintf('Subsonic MachNumber: %.2f',MachNumber); %prints subsonic mach number rounded to 2 decimal places
elseif (MachNumber == 1) %executes if mach number is equal to 1
    fprintf('Sonic MachNumber: %.2f',MachNumber); %prints sonic mach number rounded to 2 decimal places
elseif ((1 < MachNumber) && (MachNumber <= 5)) %executes if mach number is greater than 1 but less than or equal to 5
    MachAngle = asind(1/MachNumber); %computes mach angle
    fprintf('Supersonic MachNumber: %.2f MachAngle: %.0f',MachNumber,MachAngle); %prints supersonic mach number rounded to 2 decimal places and mach angle rounded to an integer
elseif (MachNumber > 5) %executes is mach number is greater than 5
    fprintf('Hypersonic MachNumber: %.2f',MachNumber); %%prints hypersonic mach number rounded to 2 decimal places
end %ends if/elseif statments 












