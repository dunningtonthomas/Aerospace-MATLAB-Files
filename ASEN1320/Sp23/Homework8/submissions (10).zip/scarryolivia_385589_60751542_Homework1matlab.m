load data.mat
AltitudeVector= data(:,1);%coloum 1 of data
SoundSpeedVector= data(:,3);%coloum 3 of data

%Speed = input("Speed: ");
%Altitude = input("Altitdue: ");

tempAltitude = AltitudeVector==Altitude;
isAltitude = AltitudeVector(tempAltitude);


%find a value of sound speed at Altitude, compute Mach number, and assing
%it to a variable named MachNumber

MachNumber= Speed/Altitude;
MachAngle=asin((1/MachNumber)*pi/180);
MachNumber=round(MachAngle,2);

if (MachNumber < 1)
    fprintf("Subsonic MachNumber: %.2f",MachNumber);
elseif (MachNumber == 1)
    fprintf("Sonic MachNumber: %.2f",MachNumber);
elseif((1<MachNumber)<=5)
    MachAngle=asin((1/MachNumber)*pi/180);
    fprintf("Supersonic MachNumber: %.2f MachAngle: %d ",MachNumber,MachAngle);
elseif (5<MachNumber)
    fprintf("Hypersonic MachNumber: %.2f",MachNumber);
end