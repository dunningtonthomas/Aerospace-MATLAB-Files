% Load data.mat into 2D matrix titled 'data'

load('data.mat','data');

% Initialize AltitudeVector with 1st Column of Data
% Initialize SoundSpeedVector with 3rd Column of Data

AltitudeVector = data(:,1);
SoundSpeedVector = data(:,3);

% Prompt User to Inpur Speed and Altitude Values

PromptSpeed = 'Speed: ';
PromptAltitude = 'Altitude: ';

Speed = input(PromptSpeed);
Altitude = input(PromptAltitude);

% Index AltitudeVector: which Vector Element is Closest to User Input

[isAltitude,I] = min(abs(AltitudeVector - Altitude));

% Calculate Mach Number

MachNumber = Speed/SoundSpeedVector(I);

% Conditional Statements for Displaying Flight Regime Type
% Displays Mach Number
% SUPERSONIC: Calculate MachAngle and Display Result

if MachNumber < 1
    fprintf("Subsonic MachNumber: %.2f \n", MachNumber);

elseif MachNumber == 1
    fprintf("Sonic MachNumber: %.2f \n", MachNumber);

elseif MachNumber > 1 && MachNumber <= 5
    angle = asind(1/MachNumber);
    angler = round(angle);
    fprintf("Supersonic MachNumber: %.2f", MachNumber);
    fprintf(" MachAngle: %.0f \n", angler);

elseif MachNumber > 5
    fprintf("Hypersonic MachNumber: %.2f \n", MachNumber);

end

