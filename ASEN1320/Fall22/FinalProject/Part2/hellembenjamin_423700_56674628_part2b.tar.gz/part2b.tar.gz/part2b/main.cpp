//Libraries and namespaces
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include "coord.h"
using namespace std; 

//Function Prototypes
void ReadCSV (double [] , string);
void WriteCSV(bool[], int, string);

//Main function 
int main (){
    
    // Creation of an array of Coord for each spacecraft
    double Sat1pos[1442 * 3], Sat2pos[1442*3], GSPosition[1442*3]; 
    bool Sat1Vis[1440], Sat2Vis[1440]; 
    string S1file = "Sat1Position.csv";
    string S2file = "Sat2Position.csv";
    string GSfile = "GSPosition.csv"; 
    
    //Reading in data from the Sat1Position.csv, Sat2Position.csv, and GSPosition.csv files created in Parts 1.2 and 2.1.
    ReadCSV(Sat1pos, S1file); 
    ReadCSV(Sat2pos, S2file); 
    ReadCSV(GSPosition, GSfile); 
    
    //Setting values of the ground station and spacecraft position variables for each object
    for (int i= 0; i<1441; i++){
        
        Coord Sat1Object[1441]; 
        Sat1Object[i].setPoint(Sat1pos[(3*i)], Sat1pos[(3*i)+1], Sat1pos[(3*i)+2], GSPosition[(3*i)], GSPosition[(3*i)+1], GSPosition[(3*i)+2]); 
        Sat1Vis[i] = Sat1Object[i].setFlag(); 
        
        
        Coord Sat2Object[1441]; 
        Sat2Object[i].setPoint(Sat2pos[(3*i)], Sat2pos[(3*i)+1], Sat2pos[(3*i)+2], GSPosition[(3*i)], GSPosition[(3*i)+1], GSPosition[(3*i)+2]); 
        Sat2Vis[i] = Sat2Object[i].setFlag(); 
        
    
    }
   
    WriteCSV(Sat1Vis, 1440, "Sat1Visability.csv");
    WriteCSV(Sat1Vis, 1440, "Sat2Visability.csv");
}

//Write CSV function writing out the values of the CSV file 
void WriteCSV (bool array[], int arrLen, string filename){
    ofstream CSVfile(filename);
    
    for (int i=0; i < arrLen; i++){
        CSVfile << array[i] << ", ";
    }
}

//Function that takes in 1D array and filename and reads data into an array 
void ReadCSV (double array[], string filename){

    fstream CSVfile(filename); //initiates file as fstream object 
    vector<string> r; // opens file with soecific filename 
    string L, n; // Initiates line and number as objects of string data type 
    if (CSVfile.is_open()){ //check if file is open 
        int Lnumber = 0; // Sets Lnumber to 0 to read from the start of the file 
        while ((getline(CSVfile, L))){ // loops through entire file 
            r.clear(); // changes the vector object after clearing the rows
            int Cnumber = 0; // column is set to zero in order to read from left to right
            stringstream str(L); // Sutns line into sstream in order to parse through the values in the next line
            while (getline(str, n, ',')){ // loops through line delimeter 
                r.push_back(n); // appends value to vecotr using pushback method
                array[(Lnumber * 3) + Cnumber] = stod(n); // converting string into double and assigning appropriate vector index
                Cnumber ++; //increment column by 1
                
            }
            Lnumber ++; //Increment line by 1
        }
        CSVfile.close(); //closes csv file 
    }
    else{
        cout << "Error loading the file." << endl; 
    }
}   