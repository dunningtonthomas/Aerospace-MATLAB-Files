#include <iostream>
#include <cmath>
#include "coord.h"
using namespace std; 
const double pi= 3.141592653589793;

//Setting the values of the ground station and soacecraft for each object
void Coord::setPoint(double xs, double ys, double zs, double xg, double yg, double zg){
     xspoint = xs; 
     yspoint = ys; 
     zspoint = zs; 
     xgpoint = xg; 
     ygpoint = yg; 
     zgpoint = zg; 
}

//Setting a value of the visibility flag variable for each object
bool Coord::setFlag(){
    
    //These are all the caluclations for the masking angle named phipoint
    double Rd[3] = {xspoint - xgpoint, yspoint - ygpoint, zspoint - zgpoint};
    double RdRgs = Rd[0] * xgpoint + Rd[1] * ygpoint + Rd[2] *zgpoint; 
    
    //Normal vectors 
    double RgsNorm = sqrt((xgpoint * xgpoint) + (ygpoint * ygpoint) + (zgpoint * zgpoint));
    double RdNorm = sqrt((Rd[0] * Rd[0]) + (Rd[1] * Rd[1]) + (Rd[2] * Rd[2])); 
    
    double phipoint = (pi / 2) - acos(RdRgs/(RgsNorm*RdNorm)); 

    //True statement for visibility if angle is between 10 and 80 degrees
    if (phipoint > ((10*pi)/180) && (phipoint < (80*pi)/180) ){
        flagpoint = true; 
    }
    
    
    return flagpoint; 
}

// Displays the values of the ground station and soacecraft for each object
void Coord::displayInfo(){
    
    cout << xspoint << ", " << yspoint << ", " << zspoint << ", " << xgpoint << ", " << ygpoint << ", " << zgpoint << ", " << phipoint<< endl;  
    
}