#include <string>
void rotate(double [], int, double);

void write_csv(double [], int, std::string);


//stuff that was in the utilities.cpp file that i moved here temp
// Write "rotate" fucntion that takes 1D array of type double of a certain length and modifies values as instructed  

// Write  "write_csv" function that writes out values stored in 1D array of type double of a certain lenth to cvs file as instructed
