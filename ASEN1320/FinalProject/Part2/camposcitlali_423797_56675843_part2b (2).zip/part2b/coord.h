#include <string>
class coord{
    
    
    public: 
        bool setFlag(); 
        void setPoint();
        double displayInfo();
        
    private:
        double xspoint;
        double yspoint;
        double zspoint;
        double xgpoint;
        double ygpoint;
        double zgpoint;
        double phipoint;
        bool flagpoint;
    
};