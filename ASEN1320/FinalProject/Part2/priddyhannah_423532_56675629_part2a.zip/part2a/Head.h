#include <iostream>
#include <string>
#include <fstream>
#include <cmath>

using namespace std;


void rotategs(double [], int, double []); 
void write_csvgs(double [], int, string);
