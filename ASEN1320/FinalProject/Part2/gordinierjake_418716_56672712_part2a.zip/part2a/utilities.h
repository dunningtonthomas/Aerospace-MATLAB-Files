#include <string>
void rotate(double [], int, double); 
void write_csv(double [], int, std::string);