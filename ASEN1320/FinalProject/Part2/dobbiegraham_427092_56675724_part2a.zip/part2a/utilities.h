#include <string>
#include <fstream>
#include <iostream>
#include <math.h>


void rotate(double station_data[], int data_len, double angle); 

void write_csv(double [], int, std::string);


