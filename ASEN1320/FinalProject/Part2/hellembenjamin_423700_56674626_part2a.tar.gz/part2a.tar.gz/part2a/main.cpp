#include "utilities.h"
#include <iostream>
using namespace std; 


int main(){

 //Declaration of rotate function inputs 
int length = 1441*3; 
double position[length]; 
double theta; 

//Calling the rotate function 
rotate(position, length, theta);

//For loop that iterates through all 1441 values of the array and outputs the x, y, and z values of ground station. 
for (int i=0; i < 1441; i++){
    cout << position[(3*i)] << ", " << position[(3*i) + 1] << ", "  << position[(3*i)+2] << endl;
}

//Calling the write csv function 
write_csv(position, length, "GSPosition.csv");
    
return 0; 
}


