#include <iostream>
#include <cmath>
#include <fstream>
using namespace std; 

//Function prototypes
void rotate(double [], int, double); 
void write_csv(double [], int, string);

//Declaration of initial positions of ground station 
double Xinitial = -2314.87; 
double Yinitial = 4663.275; 
double Zinitial = 3673.747; 

//Rotate function 
void rotate(double P[], int L, double angle)
{
    const double pi= 3.141592653589793;
    double Xtemp;
    double Ytemp;
    double Ztemp; 
    double w = (2 * pi) / 86400; 
    
    P[0] = Xinitial;
    P[1] = Yinitial;
    P[2] = Zinitial;
       
    for (int i=1; i<1441; i++)
    {
       Xtemp = cos(w * i * 60) * Xinitial - sin(w * i * 60) * Yinitial;
       Ytemp = sin(w * i * 60) * Xinitial + cos(w * i * 60) * Yinitial;
       Ztemp = Zinitial;
       
       P[3 * i] = Xtemp;
       P[(3 * i) + 1] = Ytemp;
       P[(3 * i) + 2] = Ztemp; 
    }
}

//Write CSV function 
void write_csv(double P[], int L, std::string)
{
    ofstream my_output_file("GSPosition.csv");
    
    for (int i=0; i<L; i += 3)
    {
        my_output_file << P[i] << ", " << P[i + 1] << ", " << P[i + 2] << endl; 
    }
    my_output_file.close();
}


