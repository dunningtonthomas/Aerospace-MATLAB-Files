//declaring the class as coord
class coord
{
    //mutator methods
    
        public:
    
        void setPoint(double, double, double, double, double, double);
        void displayInfo();
        bool setFlag();
        
//private attributes  

    private:
    
        double xspoint;
        double yspoint;
        double zspoint;
        double xgpoint;
        double ygpoint;
        double zgpoint;
        double phipoint;
        bool flagpoint;
        


};